package monet

import (
	"errors"
	"net"
	"time"
	"database/sql/driver"
)



type fakeserver struct {
	cs string
	cr string
	dc bool
	conn
}

func newFakeServer() Server {
	return new(fakeserver)
}

func (fs *fakeserver) Connect(hostname, port, username, password, database, language string, timeout time.Duration) error {
	fs.setConn(hostname, port, username, password, database, language)
	return nil
}

func (fs *fakeserver) setConn(hostname, port, username, password, database, language string) {
	fs.hostname = hostname
	fs.port = port
	fs.username = username
	fs.password = password
	fs.database = database
	fs.language = language
	fs.netConn = newFakeConn().(net.Conn)
	return
}

func (fs *fakeserver) Cmd(operation string) (response string, err error) {
	fs.cr = operation
	return
}

func (fs *fakeserver) Disconnect() error {
	fs.dc = true
	return nil
}

type fakeMConn struct {
	stmt driver.Stmt
	err error
	query string
	isClosed bool
	tx driver.Tx
}

func (c *fakeMConn) exec(query string) {
	c.query = query
}

func (c *fakeMConn)Prepare(query string) (driver.Stmt, error){
	c.query = query
	return c.stmt, err
}

func (c *fakeMConn)Close() error{
	c.isClosed = true
	return c.err
}

func (c *fakeMConn)Begin()(driver.Tx, error){
	return c.tx, c.err
}

type fakeMStmt struct {
	numInput int
	result driver.Result
	err error
	args []driver.Value
	rows driver.Rows
	isClosed bool
}

func (fms *fakeMStmt)Close() error{
	fms.isClosed = true
	return fms.err
}

func (fms *fakeMStmt)NumInput()int{
	return fms.numInput
}

func (fms *fakeMStmt)Exec(args []driver.Value)(driver.Result, error){
	fms.args = args
	return fms.result, fms.err
}

func (fms *fakeMStmt)Query(args []driver.Value)(driver.Rows, error){
	fms.args = args
	return fms.rows, fms.err
}
